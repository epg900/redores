import hashlib,sys,os

arg1=sys.argv[1]
sha_dig=hashlib.sha256(open(arg1,'rb').read()).hexdigest()
sha2_dig=hashlib.sha512(open(arg1,'rb').read()).hexdigest()
md5_dig=hashlib.md5(open(arg1,'rb').read()).hexdigest()
print(f'hashs of file : {arg1} \n')
print('#######################################################')
print('\nSHA512 hash code: \n')
print(sha2_dig)
print('\nSHA256 hash code: \n')
print(sha_dig)
print('\nMD5 hash code: \n')
print(md5_dig)
print('\n')
with open('chk_hash.txt','w') as f:
    f.write(f'hashs of file : {arg1} \n')
    f.write('#######################################################')
    f.write('\n\nSHA512 hash code: \n\n')
    f.write(sha2_dig)
    f.write('\n\nSHA256 hash code: \n\n')
    f.write(sha_dig)
    f.write('\n\nMD5 hash code: \n\n')
    f.write(md5_dig)
os.system('pause')
      
